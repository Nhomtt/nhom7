package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnFadein, btnFadeout, btnRepeat, btnZoomIn, btnZoomOut;
    ImageView imageView;
    Animation anim_FadeIn, anim_FadeOut, anim_Repeat,anim_ZoomIn, anim_ZoomOut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AnhXa();
        Animation();
        Nhan();
    }

    private  void Nhan(){
        btnFadein.setOnClickListener(this);
        btnFadeout.setOnClickListener(this);
        btnRepeat.setOnClickListener(this);
        btnZoomIn.setOnClickListener(this);
        btnZoomOut.setOnClickListener(this);
    }
    private  void Animation(){
        anim_FadeIn = AnimationUtils.loadAnimation(this,R.anim.anim_fadein);
        anim_FadeOut = AnimationUtils.loadAnimation(this,R.anim.anim_fadeout);
        anim_Repeat = AnimationUtils.loadAnimation(this,R.anim.anim_repeat);
        anim_ZoomIn = AnimationUtils.loadAnimation(this,R.anim.anim_zoomin);
        anim_ZoomOut = AnimationUtils.loadAnimation(this,R.anim.anim_zoomout);
    }
    private  void AnhXa()
    {
        imageView =(ImageView) findViewById(R.id.imgtraibong);
        btnFadein = (Button)findViewById(R.id.btnFadein);
        btnFadeout = (Button)findViewById(R.id.btnFadeout);
        btnRepeat = (Button)findViewById(R.id.btnRepeat);
        btnZoomIn = (Button)findViewById(R.id.btnZoomIn);
        btnZoomOut = (Button)findViewById(R.id.btnZoomOut);
    }

    @Override
    public void onClick(View v) {
        if (v==btnFadein){
            imageView.startAnimation(anim_FadeIn);
        }
        if (v==btnFadeout){
            imageView.startAnimation(anim_FadeOut);
        }
        if (v==btnRepeat){
            imageView.startAnimation(anim_Repeat);
        }
        if (v==btnZoomIn){
            imageView.startAnimation(anim_ZoomIn);
        }
        if (v==btnZoomOut){
            imageView.startAnimation(anim_ZoomOut);
        }
    }
}
