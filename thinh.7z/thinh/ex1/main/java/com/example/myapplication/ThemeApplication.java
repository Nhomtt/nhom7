package com.example.myapplication;

import android.app.Application;

public class ThemeApplication extends Application {
    public static int currentPosition;

}
